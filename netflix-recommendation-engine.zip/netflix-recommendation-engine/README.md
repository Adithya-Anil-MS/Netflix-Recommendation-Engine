# 🎬 Netflix Recommendation Engine

A movie recommendation system built with **User-Based Collaborative Filtering**, trained on user watch history and genre preferences using **Scikit-learn** and **Pandas**.

---

## 📌 Project Overview

| Item | Detail |
|---|---|
| Algorithm | User-Based Collaborative Filtering |
| Similarity Metric | Cosine Similarity |
| Libraries | Scikit-learn, Pandas, NumPy, Matplotlib, Seaborn |
| Evaluation Metrics | RMSE, MAE |
| Python Version | 3.10+ |

---

## 🗂️ Project Structure

```
netflix-recommendation-engine/
│
├── data/
│   └── movies.csv                    # Dataset (userId, title, genres, rating)
│
├── notebooks/
│   └── EDA_and_Modelling.ipynb       # Full Jupyter notebook walkthrough
│
├── src/
│   ├── __init__.py
│   ├── preprocessing.py              # EDA, label encoding, feature scaling
│   ├── model.py                      # Collaborative Filtering model class
│   └── recommend.py                  # Recommendation & display utilities
│
├── app.py                            # Main pipeline — run this
├── generate_sample_data.py           # Creates a sample dataset for testing
├── requirements.txt
├── .gitignore
└── README.md
```

---

## ⚙️ Setup & Installation

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/netflix-recommendation-engine.git
cd netflix-recommendation-engine
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv

# Activate:
# Windows:
venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Generate sample dataset (if you don't have one)
```bash
python generate_sample_data.py
```
This creates `data/movies.csv` with 200 synthetic users and 30 movies.

### 5. Run the recommendation engine
```bash
python app.py
```

---

## 🔍 How It Works

```
Raw CSV
  │
  ▼
Load & EDA ──► Missing values, distributions, genre frequency plots
  │
  ▼
Preprocessing ──► Label Encoding (genres) + MinMaxScaler (ratings)
  │
  ▼
User-Movie Matrix ──► Pivot table: rows = users, columns = movies
  │
  ▼
Cosine Similarity ──► Pairwise similarity between all users
  │
  ▼
Neighbourhood ──► Find top-K most similar users for a target user
  │
  ▼
Weighted Prediction ──► Score = Σ(similarity × rating) / Σ|similarity|
  │
  ▼
Recommendations ──► Top-N unseen movies, ranked by predicted score
```

---

## ⚙️ Configuration

Edit the `CONFIG` block at the top of `app.py`:

```python
DATA_PATH       = "data/movies.csv"
USER_COL        = "userId"
MOVIE_COL       = "title"
RATING_COL      = "rating"
GENRE_COL       = "genres"
SAMPLE_USER_ID  = 1         # Target user
TOP_N           = 10        # Number of recommendations
PREFERRED_GENRE = "Action"  # Genre filter
SAVE_PLOTS      = False     # Save EDA plots to /outputs/
```

---

## 📊 Sample Output

```
███████████████████████████████████████████████████████
  Netflix Recommendation Engine
  Collaborative Filtering | Scikit-learn + Pandas
███████████████████████████████████████████████████████

[Step 1] Loading data & performing EDA...
[Step 4] Building Collaborative Filtering model...
  User-Movie matrix: 200 users × 30 movies

──────────────────────────────────────────
  Model Evaluation Results
──────────────────────────────────────────
  Predictions made : 312
  RMSE             : 0.4823
  MAE              : 0.3741
──────────────────────────────────────────

═══════════════════════════════════════════════════════
  Top 10 Recommendations for User: 1
═══════════════════════════════════════════════════════
   1. Inception                         score: 0.8921  ████
   2. The Dark Knight                   score: 0.8734  ████
   3. Interstellar                      score: 0.8102  ████
   ...
```

---

## 📓 Jupyter Notebook

Open the full EDA and modelling walkthrough:

```bash
jupyter notebook notebooks/EDA_and_Modelling.ipynb
```

---

## 🛠️ Tech Stack

![Python](https://img.shields.io/badge/Python-3.10-blue?logo=python)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-1.3.2-orange?logo=scikit-learn)
![Pandas](https://img.shields.io/badge/Pandas-2.1.4-green?logo=pandas)
![NumPy](https://img.shields.io/badge/NumPy-1.26.2-blue?logo=numpy)
![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-orange?logo=jupyter)

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

## 👤 Author

**Your Name**
[GitHub](https://github.com/YOUR_USERNAME) · [LinkedIn](https://linkedin.com/in/YOUR_PROFILE)
