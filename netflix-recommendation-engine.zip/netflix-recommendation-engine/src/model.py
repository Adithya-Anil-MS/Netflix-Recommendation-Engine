"""
model.py
--------
User-Based Collaborative Filtering model using Cosine Similarity.
"""

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import warnings
warnings.filterwarnings("ignore")


class CollaborativeFilteringModel:
    """
    User-Based Collaborative Filtering Recommender.

    Workflow
    --------
    1. Build a User × Movie rating matrix.
    2. Compute pairwise cosine similarity between users.
    3. For a target user, find the K most similar users.
    4. Predict ratings as a weighted average of similar users' ratings.
    5. Recommend top-N unseen movies ranked by predicted score.

    Attributes
    ----------
    user_movie_matrix  : pd.DataFrame — pivot table (users × movies)
    user_similarity_df : pd.DataFrame — cosine similarity matrix
    """

    def __init__(self):
        self.user_movie_matrix  = None
        self.user_similarity_df = None
        self._user_col  = None
        self._movie_col = None

    # ── 1. Build Matrix ──────────────────────────────────────

    def build_user_movie_matrix(
        self,
        df: pd.DataFrame,
        user_col: str,
        movie_col: str,
        rating_col: str
    ) -> pd.DataFrame:
        """
        Create User-Movie pivot matrix.

        Parameters
        ----------
        df         : pd.DataFrame
        user_col   : str — column name for user IDs
        movie_col  : str — column name for movie titles/IDs
        rating_col : str — column name for numeric ratings

        Returns
        -------
        pd.DataFrame (users as index, movies as columns)
        """
        self._user_col  = user_col
        self._movie_col = movie_col

        self.user_movie_matrix = df.pivot_table(
            index=user_col,
            columns=movie_col,
            values=rating_col,
            fill_value=0
        )
        print(f"[model] User-Movie matrix: {self.user_movie_matrix.shape[0]} users × "
              f"{self.user_movie_matrix.shape[1]} movies")
        return self.user_movie_matrix

    # ── 2. Compute Similarity ────────────────────────────────

    def compute_similarity(self) -> pd.DataFrame:
        """
        Compute cosine similarity between all users.

        Returns
        -------
        pd.DataFrame — symmetric similarity matrix (users × users)
        """
        if self.user_movie_matrix is None:
            raise RuntimeError("Call build_user_movie_matrix() first.")

        sim_matrix = cosine_similarity(self.user_movie_matrix)
        self.user_similarity_df = pd.DataFrame(
            sim_matrix,
            index=self.user_movie_matrix.index,
            columns=self.user_movie_matrix.index
        )
        print(f"[model] Cosine similarity matrix computed — "
              f"{self.user_similarity_df.shape[0]}×{self.user_similarity_df.shape[1]}")
        return self.user_similarity_df

    # ── 3. Similar Users ─────────────────────────────────────

    def get_similar_users(self, user_id, top_n: int = 10) -> pd.Series:
        """
        Retrieve the top-N most similar users for a given user.

        Parameters
        ----------
        user_id : any — must exist in the similarity matrix index
        top_n   : int — number of similar users to return

        Returns
        -------
        pd.Series — (user_id → similarity_score), descending
        """
        if self.user_similarity_df is None:
            raise RuntimeError("Call compute_similarity() first.")
        if user_id not in self.user_similarity_df.index:
            raise ValueError(f"User '{user_id}' not found in matrix.")

        similar = (
            self.user_similarity_df[user_id]
            .drop(user_id)          # exclude self
            .sort_values(ascending=False)
        )
        return similar.head(top_n)

    # ── 4. Predict Rating ────────────────────────────────────

    def predict_rating(self, user_id, movie: str) -> float:
        """
        Predict what rating a user would give to a specific movie.

        Uses weighted average:
            predicted = Σ(sim(u, v) × rating(v, m)) / Σ|sim(u, v)|

        Parameters
        ----------
        user_id : any
        movie   : str — movie title/ID in the matrix columns

        Returns
        -------
        float — predicted rating (0 if not computable)
        """
        if movie not in self.user_movie_matrix.columns:
            return 0.0

        sim_scores   = self.user_similarity_df[user_id]
        movie_ratings = self.user_movie_matrix[movie]

        numerator   = np.dot(sim_scores, movie_ratings)
        denominator = np.sum(np.abs(sim_scores))

        return float(numerator / denominator) if denominator != 0 else 0.0

    # ── 5. Evaluate ──────────────────────────────────────────

    def evaluate(
        self,
        df: pd.DataFrame,
        user_col: str,
        movie_col: str,
        rating_col: str,
        test_size: float = 0.2,
        random_state: int = 42
    ) -> dict:
        """
        Train/test split evaluation using RMSE and MAE.

        Parameters
        ----------
        df           : pd.DataFrame — full dataset
        user_col     : str
        movie_col    : str
        rating_col   : str
        test_size    : float — fraction of data for testing
        random_state : int

        Returns
        -------
        dict with keys: 'rmse', 'mae', 'n_predictions'
        """
        train, test = train_test_split(df, test_size=test_size, random_state=random_state)

        # Rebuild model on training data
        self.build_user_movie_matrix(train, user_col, movie_col, rating_col)
        self.compute_similarity()

        predictions, actuals = [], []

        for _, row in test.iterrows():
            user   = row[user_col]
            movie  = row[movie_col]
            actual = row[rating_col]

            in_matrix = (
                user  in self.user_similarity_df.index and
                movie in self.user_movie_matrix.columns
            )
            if in_matrix:
                pred = self.predict_rating(user, movie)
                predictions.append(pred)
                actuals.append(actual)

        if not predictions:
            print("[evaluate] No predictions could be made (test users/movies not in train).")
            return {"rmse": None, "mae": None, "n_predictions": 0}

        rmse = np.sqrt(mean_squared_error(actuals, predictions))
        mae  = np.mean(np.abs(np.array(actuals) - np.array(predictions)))

        print("\n" + "─" * 40)
        print(f"  Model Evaluation Results")
        print("─" * 40)
        print(f"  Predictions made : {len(predictions)}")
        print(f"  RMSE             : {rmse:.4f}")
        print(f"  MAE              : {mae:.4f}")
        print("─" * 40)

        return {"rmse": rmse, "mae": mae, "n_predictions": len(predictions)}
