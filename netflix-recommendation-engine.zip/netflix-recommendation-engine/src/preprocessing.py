"""
preprocessing.py
----------------
Handles data loading, EDA, label encoding, and feature scaling
for the Netflix Recommendation Engine.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
import warnings
warnings.filterwarnings("ignore")


# ─────────────────────────────────────────────
# 1. DATA LOADING
# ─────────────────────────────────────────────

def load_data(filepath: str) -> pd.DataFrame:
    """
    Load dataset from a CSV file.

    Parameters
    ----------
    filepath : str
        Path to the CSV file (e.g., 'data/movies.csv')

    Returns
    -------
    pd.DataFrame
        Raw dataframe.
    """
    df = pd.read_csv(filepath)
    print(f"[load_data] Loaded '{filepath}' — shape: {df.shape}")
    print(df.head(3))
    return df


# ─────────────────────────────────────────────
# 2. EXPLORATORY DATA ANALYSIS
# ─────────────────────────────────────────────

def eda(df: pd.DataFrame, save_plots: bool = False) -> pd.DataFrame:
    """
    Perform Exploratory Data Analysis.

    Prints:
      - Missing values per column
      - Data types
      - Basic statistics
      - Rating distribution plot

    Parameters
    ----------
    df          : pd.DataFrame — raw dataframe
    save_plots  : bool         — if True, saves plots to /outputs/

    Returns
    -------
    pd.DataFrame with missing rows dropped.
    """
    print("\n" + "=" * 50)
    print("  EXPLORATORY DATA ANALYSIS")
    print("=" * 50)

    # Missing values
    missing = df.isnull().sum()
    print(f"\nMissing values:\n{missing[missing > 0] if missing.sum() > 0 else 'None'}")

    # Data types
    print(f"\nData types:\n{df.dtypes}")

    # Stats
    print(f"\nBasic statistics:\n{df.describe()}")

    # Rating distribution
    if "rating" in df.columns:
        plt.figure(figsize=(8, 4))
        sns.histplot(df["rating"], bins=10, kde=True, color="#2E75B6")
        plt.title("Rating Distribution")
        plt.xlabel("Rating")
        plt.ylabel("Count")
        plt.tight_layout()
        if save_plots:
            import os
            os.makedirs("outputs", exist_ok=True)
            plt.savefig("outputs/rating_distribution.png", dpi=150)
            print("[eda] Saved plot → outputs/rating_distribution.png")
        plt.show()

    # Genre frequency (if column present)
    if "genres" in df.columns:
        genre_counts = df["genres"].str.split("|").explode().value_counts().head(15)
        plt.figure(figsize=(10, 5))
        sns.barplot(x=genre_counts.values, y=genre_counts.index, palette="Blues_r")
        plt.title("Top 15 Genres")
        plt.xlabel("Count")
        plt.tight_layout()
        if save_plots:
            plt.savefig("outputs/genre_distribution.png", dpi=150)
            print("[eda] Saved plot → outputs/genre_distribution.png")
        plt.show()

    # Drop missing
    df_clean = df.dropna().reset_index(drop=True)
    print(f"\n[eda] Rows after dropping NaN: {len(df_clean)} (removed {len(df) - len(df_clean)})")
    return df_clean


# ─────────────────────────────────────────────
# 3. LABEL ENCODING
# ─────────────────────────────────────────────

def encode_features(df: pd.DataFrame, categorical_cols: list) -> pd.DataFrame:
    """
    Label-encode specified categorical columns.
    Encoded values are stored in new columns: <col>_encoded.

    Parameters
    ----------
    df               : pd.DataFrame
    categorical_cols : list of str — column names to encode

    Returns
    -------
    pd.DataFrame with added *_encoded columns.
    """
    le = LabelEncoder()
    for col in categorical_cols:
        if col in df.columns:
            df[col + "_encoded"] = le.fit_transform(df[col].astype(str))
            print(f"[encode] '{col}' → '{col}_encoded' | unique labels: {df[col].nunique()}")
        else:
            print(f"[encode] WARNING: column '{col}' not found — skipped.")
    return df


# ─────────────────────────────────────────────
# 4. FEATURE SCALING
# ─────────────────────────────────────────────

def scale_features(df: pd.DataFrame, numeric_cols: list):
    """
    Scale numeric columns to [0, 1] using MinMaxScaler.

    Parameters
    ----------
    df           : pd.DataFrame
    numeric_cols : list of str — columns to scale

    Returns
    -------
    (pd.DataFrame, MinMaxScaler) — modified dataframe + fitted scaler.
    """
    scaler = MinMaxScaler()
    valid_cols = [c for c in numeric_cols if c in df.columns]
    df[valid_cols] = scaler.fit_transform(df[valid_cols])
    print(f"[scale] Scaled columns: {valid_cols}")
    return df, scaler
