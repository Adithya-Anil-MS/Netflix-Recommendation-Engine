"""
recommend.py
------------
Top-N recommendation generator and result display utilities.
"""

import pandas as pd
from src.model import CollaborativeFilteringModel


def get_recommendations(
    model: CollaborativeFilteringModel,
    user_id,
    top_n: int = 10,
    similar_users: int = 20
) -> list:
    """
    Generate top-N movie recommendations for a user.

    Strategy
    --------
    1. Find the most similar users (neighbours).
    2. Collect all movies those neighbours rated.
    3. Exclude movies the target user has already seen.
    4. Rank remaining movies by predicted score (weighted by similarity).

    Parameters
    ----------
    model         : CollaborativeFilteringModel — trained model
    user_id       : any                         — target user
    top_n         : int                         — number of recommendations
    similar_users : int                         — neighbourhood size

    Returns
    -------
    list of (movie_title, score) tuples, ranked descending.
    """
    neighbours = model.get_similar_users(user_id, top_n=similar_users)

    # Movies the target user has already watched
    user_row     = model.user_movie_matrix.loc[user_id]
    already_seen = set(user_row[user_row > 0].index)

    # Aggregate weighted scores from neighbours
    scores = {}
    for neighbour, similarity in neighbours.items():
        neighbour_row = model.user_movie_matrix.loc[neighbour]
        for movie, rating in neighbour_row.items():
            if movie not in already_seen and rating > 0:
                scores[movie] = scores.get(movie, 0.0) + similarity * rating

    # Sort and return top-N
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    top    = ranked[:top_n]

    _print_recommendations(user_id, top)
    return top


def get_genre_recommendations(
    model: CollaborativeFilteringModel,
    df: pd.DataFrame,
    user_id,
    preferred_genre: str,
    movie_col: str = "title",
    genre_col: str = "genres",
    top_n: int = 10
) -> list:
    """
    Filter recommendations to a preferred genre.

    Parameters
    ----------
    model            : CollaborativeFilteringModel
    df               : pd.DataFrame — original dataset (for genre lookup)
    user_id          : any
    preferred_genre  : str — e.g. 'Action', 'Comedy', 'Drama'
    movie_col        : str
    genre_col        : str
    top_n            : int

    Returns
    -------
    list of (movie_title, score) tuples filtered by genre.
    """
    # Build a set of movies in the preferred genre
    genre_movies = set(
        df[df[genre_col].str.contains(preferred_genre, case=False, na=False)][movie_col]
    )

    all_recs = get_recommendations(model, user_id, top_n=100)
    filtered = [(m, s) for m, s in all_recs if m in genre_movies][:top_n]

    print(f"\n[genre filter] Genre: '{preferred_genre}' — {len(filtered)} recommendations")
    _print_recommendations(user_id, filtered)
    return filtered


def _print_recommendations(user_id, recommendations: list):
    """Pretty-print the recommendation list."""
    print("\n" + "=" * 55)
    print(f"  Top {len(recommendations)} Recommendations for User: {user_id}")
    print("=" * 55)
    if not recommendations:
        print("  No recommendations found.")
        return
    for rank, (movie, score) in enumerate(recommendations, 1):
        bar   = "█" * min(int(score * 5), 20)
        print(f"  {rank:>2}. {movie:<35} score: {score:.4f}  {bar}")
    print("=" * 55)
