"""
app.py
------
Entry point for the Netflix Recommendation Engine.

Usage
-----
    python app.py

To change the target user or number of recommendations,
edit the CONFIG section below.
"""

from src.preprocessing import load_data, eda, encode_features, scale_features
from src.model import CollaborativeFilteringModel
from src.recommend import get_recommendations, get_genre_recommendations
import os

# ─────────────────────────────────────────────
#  CONFIG — edit these values as needed
# ─────────────────────────────────────────────
DATA_PATH        = "data/movies.csv"
USER_COL         = "userId"
MOVIE_COL        = "title"
RATING_COL       = "rating"
GENRE_COL        = "genres"
SAMPLE_USER_ID   = 1        # Change to any valid userId in your dataset
TOP_N            = 10       # Number of recommendations to generate
PREFERRED_GENRE  = "Action" # Genre filter for genre-based recommendations
SAVE_PLOTS       = False    # Set True to save EDA plots to /outputs/
# ─────────────────────────────────────────────


def main():
    print("\n" + "█" * 55)
    print("  Netflix Recommendation Engine")
    print("  Collaborative Filtering | Scikit-learn + Pandas")
    print("█" * 55)

    # ── Step 0: Check data exists ──────────────────────────────
    if not os.path.exists(DATA_PATH):
        print(f"\n[ERROR] Dataset not found at '{DATA_PATH}'")
        print("  Run this first:  python generate_sample_data.py\n")
        return

    # ── Step 1: Load & EDA ────────────────────────────────────
    print("\n[Step 1] Loading data & performing EDA...")
    df = load_data(DATA_PATH)
    df = eda(df, save_plots=SAVE_PLOTS)

    # ── Step 2: Encode categorical features ───────────────────
    print("\n[Step 2] Encoding categorical features...")
    df = encode_features(df, categorical_cols=[GENRE_COL])

    # ── Step 3: Scale numeric features ───────────────────────
    print("\n[Step 3] Scaling numeric features...")
    df, scaler = scale_features(df, numeric_cols=[RATING_COL])

    # ── Step 4: Build model ───────────────────────────────────
    print("\n[Step 4] Building Collaborative Filtering model...")
    model = CollaborativeFilteringModel()
    model.build_user_movie_matrix(df, USER_COL, MOVIE_COL, RATING_COL)
    model.compute_similarity()

    # ── Step 5: Evaluate ──────────────────────────────────────
    print("\n[Step 5] Evaluating model (train/test split)...")
    metrics = model.evaluate(df, USER_COL, MOVIE_COL, RATING_COL)

    # ── Step 6: Recommend ─────────────────────────────────────
    print(f"\n[Step 6] Generating top-{TOP_N} recommendations for User {SAMPLE_USER_ID}...")
    recommendations = get_recommendations(model, SAMPLE_USER_ID, top_n=TOP_N)

    # ── Step 7: Genre-filtered recommendations ────────────────
    print(f"\n[Step 7] Genre-filtered recommendations ('{PREFERRED_GENRE}')...")
    try:
        # Reload unscaled data for genre lookup
        df_raw = load_data(DATA_PATH)
        genre_recs = get_genre_recommendations(
            model, df_raw, SAMPLE_USER_ID,
            preferred_genre=PREFERRED_GENRE,
            movie_col=MOVIE_COL,
            genre_col=GENRE_COL,
            top_n=5
        )
    except Exception as e:
        print(f"  [genre filter skipped] {e}")

    print("\n[Done] Recommendation pipeline complete.\n")


if __name__ == "__main__":
    main()
