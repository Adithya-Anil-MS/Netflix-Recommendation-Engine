"""
generate_sample_data.py
-----------------------
Generates a realistic sample movies.csv dataset for testing.
Run this once if you don't have a real dataset:
    python generate_sample_data.py
"""

import pandas as pd
import numpy as np
import os

np.random.seed(42)

MOVIES = [
    ("The Dark Knight",         "Action|Crime|Drama"),
    ("Inception",               "Action|Adventure|Sci-Fi"),
    ("Interstellar",            "Adventure|Drama|Sci-Fi"),
    ("The Matrix",              "Action|Sci-Fi"),
    ("Pulp Fiction",            "Crime|Drama"),
    ("The Shawshank Redemption","Drama"),
    ("The Godfather",           "Crime|Drama"),
    ("Forrest Gump",            "Drama|Romance"),
    ("The Silence of the Lambs","Crime|Horror|Thriller"),
    ("Schindler's List",        "Biography|Drama|History"),
    ("Fight Club",              "Drama|Thriller"),
    ("Goodfellas",              "Biography|Crime|Drama"),
    ("The Lord of the Rings",   "Adventure|Drama|Fantasy"),
    ("Star Wars",               "Action|Adventure|Fantasy"),
    ("Avengers: Endgame",       "Action|Adventure|Sci-Fi"),
    ("Joker",                   "Crime|Drama|Thriller"),
    ("Parasite",                "Drama|Thriller"),
    ("Get Out",                 "Horror|Mystery|Thriller"),
    ("La La Land",              "Drama|Music|Romance"),
    ("Whiplash",                "Drama|Music"),
    ("Black Panther",           "Action|Adventure|Sci-Fi"),
    ("Spider-Man: Into the Spider-Verse", "Action|Animation|Adventure"),
    ("Your Name",               "Animation|Drama|Fantasy"),
    ("Spirited Away",           "Animation|Adventure|Family"),
    ("Toy Story",               "Animation|Adventure|Comedy"),
    ("The Lion King",           "Animation|Adventure|Drama"),
    ("Titanic",                 "Drama|Romance"),
    ("Avatar",                  "Action|Adventure|Sci-Fi"),
    ("Gladiator",               "Action|Adventure|Drama"),
    ("Braveheart",              "Biography|Drama|History"),
]

NUM_USERS = 200
records   = []

for user_id in range(1, NUM_USERS + 1):
    # Each user rates a random subset of movies
    n_rated = np.random.randint(5, 20)
    rated_movies = np.random.choice(len(MOVIES), size=n_rated, replace=False)

    for idx in rated_movies:
        title, genres = MOVIES[idx]
        rating = np.clip(np.random.normal(loc=3.5, scale=1.0), 0.5, 5.0)
        rating = round(rating * 2) / 2  # Round to nearest 0.5
        records.append({
            "userId":    user_id,
            "title":     title,
            "genres":    genres,
            "rating":    rating,
            "timestamp": np.random.randint(1_000_000_000, 1_700_000_000),
        })

df = pd.DataFrame(records)
os.makedirs("data", exist_ok=True)
df.to_csv("data/movies.csv", index=False)

print(f"[generate_sample_data] Saved {len(df)} ratings for {NUM_USERS} users "
      f"across {len(MOVIES)} movies → data/movies.csv")
print(df.head(10).to_string(index=False))
